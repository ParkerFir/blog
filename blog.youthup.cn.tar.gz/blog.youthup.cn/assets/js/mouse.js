$.shuicheMouse({
    type: 11,
    color:"rgba(187,67,128,1)"
})
alert("年轻人可不要太好奇，去玩游戏摸会鱼吧！");
window.location.href="https://www.youthup.cn/game/";